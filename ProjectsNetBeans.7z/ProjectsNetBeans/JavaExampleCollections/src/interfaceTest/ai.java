/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package interfaceTest;

/**
 *
 * @author leo
 */
public class ai implements Ia{

    public void aM() {
//        throw new UnsupportedOperationException("Not supported yet.");
        System.out.println("This is aM().");
    }

}
