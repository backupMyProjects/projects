/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package interfaceTest;

/**
 *
 * @author leo
 */
public interface Ib extends Ia {
    void aM();
}
