/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package extendTest;

/**
 *
 * @author leo
 */
public class parent {
    
    public void test(){
        System.out.println("parent");
    }
    
}
