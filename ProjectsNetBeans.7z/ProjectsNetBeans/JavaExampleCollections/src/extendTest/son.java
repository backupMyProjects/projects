/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package extendTest;

/**
 *
 * @author leo
 */
public class son extends parent {
    @Override
    public void test(){
        System.out.println("son");
    }
}
