/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package extendTest;

/**
 *
 * @author leo
 */
public class a {
    void aM(){
        System.out.println("Hello a.");
    }

}
