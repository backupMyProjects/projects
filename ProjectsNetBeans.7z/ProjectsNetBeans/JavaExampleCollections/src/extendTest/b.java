/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package extendTest;

/**
 *
 * @author leo
 */
public class b extends a {
    void bM(){
        System.out.println("Hello b.");
    }
    void aM(){
        System.out.println("change to b.");
    }
}
