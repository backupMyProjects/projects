/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
//import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import LeoLib.tools.*;
import LeoLib.utils.StringUtil;
import java.util.*;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import util.Toolet;

import static LeoLib.utils.Constants.DBServer.*;

/**
 *
 * @author leo
 */
//@WebServlet(name = "getData", urlPatterns = {"/getData"})
public class getData extends HttpServlet {
    
    debug de;
    Toolet tools;
    CommonDAO cDAO;
    String prefix;
    String table;
    private void initialize(){
        de = new debug(true);
        tools = new Toolet();
        cDAO = new CommonDAO(MySQL);
    }

    /** 
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code> methods.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/xml;charset=UTF-8");
        initialize();
        //========================================
        // Get parameters
        //----------------------------------------
        String oper = tools.parmGetter(request, "oper");// select

        //========================================
        // Action
        //----------------------------------------
        List result = new ArrayList();// without this, occur the null point exception at xml page
        
        
            if( "getAPI".equals(oper) ){
                List temp = getAPI();
                result = temp == null ? result : temp;
            }else if( "getLogin".equals(oper) ){
                List temp = getLogin(request);
                result = temp == null ? result : temp;
            }else if( "getProfile".equals(oper) ){
                List temp = getProfile(request);
                result = temp == null ? result : temp;
            }else if( "getRecentlyHealthyData".equals(oper) ){
                List temp = getRecentlyHealthyData(request);
                result = temp == null ? result : temp;
            }else if( "getHealthyDataList".equals(oper) ){
                List temp = getHealthyDataList(request);
                result = temp == null ? result : temp;
            }else if( "getMessageList".equals(oper) ){
                List temp = getMessageList(request);
                result = temp == null ? result : temp;
            }else if( "getMessageListWithReceiver".equals(oper) ){
                List temp = getMessageListWithReceiver(request);
                result = temp == null ? result : temp;
            }else if( "getClientRelationList".equals(oper) ){
                List temp = getClientRelationList(request);
                result = temp == null ? result : temp;
            }else if( "getObserverRelationList".equals(oper) ){
                List temp = getObserverRelationList(request);
                result = temp == null ? result : temp;
            }else if( "getCareList".equals(oper) ){
                List temp = getCareList(request);
                result = temp == null ? result : temp;
            }else if( "getCareListViaClient".equals(oper) ){
                List temp = getCareListViaClient(request);
                result = temp == null ? result : temp;
            }else{
                de.println("Wrong Operation : "+oper);
            }//
        
        de.println("result "+result);

        //========================================
        // Set parameters
        //----------------------------------------
        request.setAttribute("resultList", result);

        ////////////////////////////////////////////////////////////////////////
        ServletContext context = getServletConfig().getServletContext();
        RequestDispatcher dispatcher = context.getRequestDispatcher("/getData.jsp");
        dispatcher.include(request, response);
    }
    
    private List getAPI(){
        return (new CommonDAO(SQLite)).getInstanceListViaSQL("SELECT * from api");
    }
    
    private List getProfile(HttpServletRequest request){
        String id_user = tools.parmGetter(request, "id_user");// selected table
        List result = null;
        result = cDAO.getInstanceListViaSQL("SELECT * from " + "user" + " where `id` = " + id_user);
        //--------------------------------------------
        return result;
    }
    
    private List getLogin(HttpServletRequest request){
        String user = tools.parmGetter(request, "user");// selected table
        String phone = tools.parmGetter(request, "phone");// selected table
        String password = tools.parmGetter(request, "password");// selected table
        
        if ( !StringUtil.isEmpStr(user) && !StringUtil.isEmpStr(password) ) {
            return cDAO.getInstanceListViaSQL("SELECT * from " + "user" + " where `user` = '" + user + "' and `password` = '" + password + "'");
        }else if ( !StringUtil.isEmpStr(phone) && !StringUtil.isEmpStr(password) ){
            return cDAO.getInstanceListViaSQL("SELECT * from " + "user" + " where `phone` = '" + phone + "' and `password` = '" + password + "'");
        }else{ return null; }
        //--------------------------------------------
        //return result1;
    }
    
    private List getRecentlyHealthyData(HttpServletRequest request){
        String id_user = tools.parmGetter(request, "id_user");// selected table
        List result = null;
        //result = cDAO.getInstanceListViaSQL("SELECT * from " + "datacollection" + " where `user_id` = " + id_user + " ORDER BY `updateTime` DESC LIMIT 0 , 1");
        result = cDAO.getInstanceListViaSQL("SELECT * from " + "getHealthyDataList" + " where `user_id` = '" + id_user + "'" + " ORDER BY updateTime DESC LIMIT 0 ,1");
        //--------------------------------------------
        return result;
    }
    
    private List getHealthyDataList(HttpServletRequest request){
        String id_user = tools.parmGetter(request, "id_user");// selected table
        List result = null;
        //result = cDAO.getInstanceListViaSQL("SELECT * from " + "datacollection" + " where `user_id` = " + id_user + " ORDER BY `updateTime` DESC");
        result = cDAO.getInstanceListViaSQL("SELECT * from " + "getHealthyDataList" + " where `user_id` = '" + id_user + "'");
        //--------------------------------------------
        return result;
    }
    
    private List getMessageList(HttpServletRequest request){
        String id_user = tools.parmGetter(request, "id_user");// selected table
        List result = null;
        //result = cDAO.getInstanceListViaSQL("SELECT message.*, user.name as receiver from " + "message, user" + " where message.`sender_id` = " + id_user + " and message.`receiver_id` = user.`id`");
        result = cDAO.getInstanceListViaSQL("SELECT * FROM `getMessageList` WHERE `sender_id` = '" + id_user + "'");
        //--------------------------------------------
        return result;
    }
    private List getMessageListWithReceiver(HttpServletRequest request){
        String id_user = tools.parmGetter(request, "id_user");// selected table
        String id_receiver = tools.parmGetter(request, "id_receiver");// selected table
        List result = null;
        //result = cDAO.getInstanceListViaSQL("SELECT message.*, user.name as receiver from " + "message, user" + " where message.`sender_id` = " + id_user + " and message.`receiver_id` = " + id_receiver + " and message.`receiver_id` = user.`id`");
        result = cDAO.getInstanceListViaSQL("SELECT * FROM `getMessageList` WHERE `sender_id` = '" + id_user + "' and `receiver_id` = '" + id_receiver + "'");
        //--------------------------------------------
        return result;
    }
    
    private List getClientRelationList(HttpServletRequest request){
        String id_user = tools.parmGetter(request, "id_user");// selected table
        List result = null;
        //result = cDAO.getInstanceListViaSQL("SELECT relation.*, user.name as client from " + "relation, user" + " where relation.`observer_id` = " + id_user + " and relation.`client_id` = user.`id`");
        result = cDAO.getInstanceListViaSQL("SELECT * FROM `getClientRelationList` WHERE `observer_id` = '" + id_user + "'");
        //--------------------------------------------
        return result;
    }
    
    private List getObserverRelationList(HttpServletRequest request){
        String id_user = tools.parmGetter(request, "id_user");// selected table
        List result = null;
        //result = cDAO.getInstanceListViaSQL("SELECT relation.*, user.name as observer from " + "relation, user" + " where relation.`client_id` = " + id_user + " and relation.`observer_id` = user.`id`");
        result = cDAO.getInstanceListViaSQL("SELECT * FROM `getObserverRelationList` WHERE `client_id` = '" + id_user + "'");
        //--------------------------------------------
        return result;
    }
    
    private List getCareList(HttpServletRequest request){
        String id_user = tools.parmGetter(request, "id_user");// selected table
        List result = null;
        //result = cDAO.getInstanceListViaSQL("SELECT relation.*, user.name as client from " + "relation, user" + " where relation.`observer_id` = " + id_user + " and relation.`client_id` = user.`id`");
        //result = cDAO.getInstanceListViaSQL("SELECT * FROM `getCareList` WHERE `observer_id` = '" + id_user + "'");
        result = cDAO.getInstanceListViaSQL("SELECT * FROM (select * from `getCareList` order by updateTime DESC) as getCareList WHERE `observer_id` = '" + id_user + "' group by user_id");
        //--------------------------------------------
        return result;
    }
    
    private List getCareListViaClient(HttpServletRequest request){
        String id_user = tools.parmGetter(request, "id_user");// selected table
        String client_id = tools.parmGetter(request, "client_id");// selected table
        List result = null;
        //result = cDAO.getInstanceListViaSQL("SELECT relation.*, user.name as client from " + "relation, user" + " where relation.`observer_id` = " + id_user + " and relation.`client_id` = user.`id`");
        //result = cDAO.getInstanceListViaSQL("SELECT * FROM `getCareList` WHERE `observer_id` = '" + id_user + "'");
        result = cDAO.getInstanceListViaSQL("SELECT * FROM (select * from `getCareList` order by updateTime DESC) as getCareList WHERE `observer_id` = '" + id_user + "'" + " and `client_id` = '" + client_id + "'");
        //--------------------------------------------
        return result;
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /** 
     * Handles the HTTP <code>GET</code> method.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /** 
     * Handles the HTTP <code>POST</code> method.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /** 
     * Returns a short description of the servlet.
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>
}
